class Post {
  final int postID;
  final String imageURL, content, postedBy, postedOn, postedAt;
  Post(this.postID, this.content, this.imageURL, this.postedBy, this.postedOn,
      this.postedAt);
}
