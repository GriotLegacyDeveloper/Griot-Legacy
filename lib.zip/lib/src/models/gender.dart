class GenderValue {
  String valueShow;
  String valueSend;
  GenderValue(this.valueShow, this.valueSend);
}
